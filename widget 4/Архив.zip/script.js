define([`${localStorage['rsDebugUrl_gt6xk2dim8nihfqc'] || './build/js/app.344225d5.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
